exports.id = 400;
exports.ids = [400];
exports.modules = {

/***/ 1025:
/***/ ((module) => {

// Exports
module.exports = {
	"placeholder": "Input_placeholder__SS7xv",
	"label": "Input_label__o6r7L",
	"input": "Input_input__2jWMJ",
	"inputContainer": "Input_inputContainer__TWXOy",
	"inputContainer2": "Input_inputContainer2__0fX21",
	"errorMsg": "Input_errorMsg__fL2_Y"
};


/***/ }),

/***/ 400:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Input)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_Input_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1025);
/* harmony import */ var _styles_Input_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_Input_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);




function Input({ label , placeholder , value , setFieldValue , name , errors  }) {
    const { 0: place , 1: setPlace  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(value[name] !== "" ? false : true);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        console.log(`${name} : ${value[name]}`);
        if (value[name] === "" || value[name] === null || value[name] === undefined) {
            setPlace(true);
        }
    }, [
        value[name]
    ]);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_styles_Input_module_css__WEBPACK_IMPORTED_MODULE_3___default().inputContainer2),
        onClick: ()=>setPlace(false)
        ,
        onFocus: ()=>setPlace(false)
        ,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_Input_module_css__WEBPACK_IMPORTED_MODULE_3___default().inputContainer),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        value: value[name],
                        onChange: (e)=>{
                            if (place) {
                                setPlace(false);
                            }
                            setFieldValue(name, e.target.value);
                        },
                        className: (_styles_Input_module_css__WEBPACK_IMPORTED_MODULE_3___default().input)
                    }),
                    place ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: (_styles_Input_module_css__WEBPACK_IMPORTED_MODULE_3___default().placeholder),
                        children: placeholder
                    }) : null
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: (_styles_Input_module_css__WEBPACK_IMPORTED_MODULE_3___default().errorMsg),
                children: (0,formik__WEBPACK_IMPORTED_MODULE_1__.getIn)(errors, name) !== undefined ? (0,formik__WEBPACK_IMPORTED_MODULE_1__.getIn)(errors, name) : ""
            })
        ]
    }));
};


/***/ })

};
;